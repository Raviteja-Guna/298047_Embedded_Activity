#ifndef ACT1_H_INCLUDED
#define ACT1_H_INCLUDED



#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>



#define LED_ON 	(0x01)			/**< LED state HIGH */
#define LED_OFF	(0x00)			/**< LED state LOW */
#define LED_PORT (PORTB)    /**< LED Port Number */
#define LED_PIN  (PORTB0)   /**< LED Pin number  */
#define BUTTON_PORT  (PORTD) /**< BUTTON Port number  */
#define HEATER_PORT  (PORTD) /**< HEATER Port number  */
#define BUTTON_PIN  (PORTD1) /**< BUTTON Pin number  */
#define HEATER_PIN  (PORTD2) /**< HEATER Pin number  */
#define SWITCH_1 !(PIND&(2<<PD0)) /**< Switch-1 pressed**/
#define SWITCH_2 !(PIND&(4<<PD0))/**< Switch-2 pressed**/
#define SET_PORTB0  DDRB |= (1<<PORTB0) /** Port B0 as output */
#define SET_PD1_AND_PD2  PORTD |= (2<<PD0)|(4<<PD0) /** PD1 and PD2 as pull-up */
#define SET_PORTD  DDRD = 0x00 /** PortD as input */
#define PWM_TempValue OCR1A

void led_State(uint8_t state);
void Init_Ports(void);
void Button_On(void);
void Heater_On(void);



void Led_Status(void);

#endif
