#ifndef ACT2_H_INCLUDED
#define ACT2_H_INCLUDED
uint16_t ReadADC(uint8_t ch);

void InitADC();
#endif
