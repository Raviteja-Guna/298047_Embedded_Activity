#ifndef ACT3_H_INCLUDED
#define ACT3_H_INCLUDED
void setup_PWM(void);
void pwmout(uint16_t);


#endif
