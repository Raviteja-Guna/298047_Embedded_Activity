#include "Activity1.h"
#include "Activity2.h"
#include "Activity3.h"


int main(void)
{
    Init_Ports();//Initialize ports for led blinking
    InitADC();//Initialize ADC ports
    uint16_t temp=0; //declare temp value to 0
    setup_PWM();//start PWM generation
    //InitUSART(103);//Initialize ports for USART
    led_State(LED_OFF);

    while(1)
          {
              if(SWITCH_1 && SWITCH_2)//checks whether switch_1 and switch_2 is ON or OFF
              {
                    led_State(LED_ON);//blinking of the led
                    _delay_ms(200);

                    temp= ReadADC(0);//reading the adjusted temp value
                    _delay_ms(200);

                    pwmout(temp);//pwm generation
                   // data_display(temp);

              }
               else
                {
                    led_State(LED_OFF);
                    _delay_ms(200);
                     OCR1A = 0; //PWM wave 0
                }
          }

    return 0;
}
